The 3D model is a case for an UnoCART used on Atari 2600 consols.
Screws should be 3x16 or similars.